# BulmaBlogTheme
> Blog Theme for VaahCMS


## Steps to clone 

#### Step 1:
Clone the repository [Bulma Blog Theme](https://github.com/webreinvent/vaahcms-theme-bulma) at ``.../VaahCms/Themes/``.

#### Step 2:
While cloning Put that ``Repo`` name ``BulmaBlogTheme``
