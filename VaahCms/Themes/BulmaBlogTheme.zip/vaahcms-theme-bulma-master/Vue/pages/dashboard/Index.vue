<script src="./IndexJs.js"></script>
<template>
    <div class="container" >

        <h1 class="title is-1">Vue Dashboard</h1>

    </div>
</template>


