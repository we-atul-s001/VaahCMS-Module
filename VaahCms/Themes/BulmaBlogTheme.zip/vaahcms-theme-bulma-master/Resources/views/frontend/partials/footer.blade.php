<footer class="footer">
    <div class="container">
        <div class="content has-text-centered">
            <p>
                <strong>Bulma Theme</strong> by <a href="https://vaah.dev/cms">VaahCms</a>.
            </p>
        </div>
    </div>
</footer>
