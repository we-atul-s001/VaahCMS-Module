<section class="hero is-primary is-small">
    <div class="hero-body">
        <div class="container">
            <h1 class="title">
                {{vh_get_theme_from_slug('bulmablogtheme')['title']}}
            </h1>
            <h2 class="subtitle">
                Medium subtitle
            </h2>
        </div>
    </div>
</section>
