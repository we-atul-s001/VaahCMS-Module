<div class="container">
    <div class="section">
            <p class="is-size-2 has-text-weight-bold">{!! get_field($data, 'headline', 'header', 'template') !!}</p>

            <br/>
            {!! get_field($data, 'content', 'header', 'template') !!}
            <br/>
    </div>
</div>
