<?php namespace VaahCms\Modules\Cms\Entities;

class ContentType extends \VaahCms\Modules\Cms\Models\ContentType
{

}
