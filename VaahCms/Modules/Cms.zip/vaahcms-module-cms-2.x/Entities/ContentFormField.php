<?php namespace VaahCms\Modules\Cms\Entities;

class ContentFormField extends \VaahCms\Modules\Cms\Models\ContentFormField {


}
