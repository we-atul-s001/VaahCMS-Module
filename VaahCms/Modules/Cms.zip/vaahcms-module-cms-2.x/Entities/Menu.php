<?php namespace VaahCms\Modules\Cms\Entities;

class Menu extends \VaahCms\Modules\Cms\Models\Menu
{


}
