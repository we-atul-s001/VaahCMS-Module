<?php namespace VaahCms\Modules\Cms\Entities;


class Content extends \VaahCms\Modules\Cms\Models\Content
{






}
