<script  setup>

</script>
<template  >

    <div>
        <h1 class="text-4xl">Dashboard</h1>
        <h1 class="text-4xl">Dashboard</h1>
        <h1 class="text-4xl">Dashboard</h1>
        <h1 class="text-4xl">Dashboard</h1>
        <h1 class="text-4xl">Dashboard</h1>
        <h1 class="text-4xl">Dashboard</h1>
        <h1 class="text-4xl">Dashboard</h1>
    </div>

</template>


